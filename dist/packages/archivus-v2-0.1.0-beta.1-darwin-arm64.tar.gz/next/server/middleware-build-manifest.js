globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/4d6a4bdf2b260495.js",
      "static/chunks/turbopack-b6f47aabaaf7bbdb.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/4d6a4bdf2b260495.js",
      "static/chunks/turbopack-b8fe854ab7c31422.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/0b01978089d98f98.js",
    "static/chunks/91adb7bdb9870c6a.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/5f11500e67954124.js",
    "static/chunks/a07208a5c2ed5b58.js",
    "static/chunks/turbopack-1a43a8b434a008d7.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];