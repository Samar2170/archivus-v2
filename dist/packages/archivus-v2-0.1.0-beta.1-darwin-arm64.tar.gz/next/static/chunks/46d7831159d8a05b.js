__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/4d6a4bdf2b260495.js",
  "static/chunks/turbopack-b6f47aabaaf7bbdb.js"
])
