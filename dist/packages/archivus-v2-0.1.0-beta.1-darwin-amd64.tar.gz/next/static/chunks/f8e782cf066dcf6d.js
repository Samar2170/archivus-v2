__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/4d6a4bdf2b260495.js",
  "static/chunks/turbopack-b8fe854ab7c31422.js"
])
